#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
double calculateAverage(int countOfNum,int arrayOfNum[countOfNum])
{
	int i;
	for(i=1;i<=countOfNum-1;i++)
	{
		arrayOfNum[0]+=arrayOfNum[i];
	}
	
	return arrayOfNum[0]/countOfNum;
	
}




int main(int argc, char *argv[]) {
	int array[]={2,2,2,2,2};
	double x=calculateAverage(5,array);
	printf("%lf",x);
	getch(0);
	system("pause");
	return 0;
}
