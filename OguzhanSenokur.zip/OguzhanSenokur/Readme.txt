Hi dear staff

You should click initially "Answer-converted.pdf". You can see your questions,project and its tasks with my answers.So you can follow the files included by this file following to below:
for Question 1 ->  OguzhanSenokur\Q1\bordaq1.c
for Question 2 ->  OguzhanSenokur\Q2\main.c
for Question 3 ->  OguzhanSenokur\Q3\bordaq3.c
for Question 4 ->  OguzhanSenokur\Q4\main.c

this way you can try how the codes work.
You can also use my instructions on the command lines.

For the project you can find datasheets with the following path:
OguzhanSenokur\Project\Brief
And codes in 
OguzhanSenokur\Project\Source Codes

Thanks for sent me the questions.It was a pleasure to solve the questions.
Best Regards...











