#include <stdio.h>
#include <stdlib.h>
#define p_uchar_d unsigned char*
#define DISC_AREA(r) 3.14*r*r //You can try this line 13 after that comment this line and uncomment line 5 and try again in line 13.
//#define DISC_AREA(r) (3.14)*(r)*(r)
#define MIN(a, b) (((a) < (b)) ? (a):(b))//
//#define MAX(a,b) (((a)>(b)) ? (a):(b))

int main(int argc, char *argv[])
 
 {
 	int x=3;
	printf("%lf\n",DISC_AREA(x+3));
/*1*/	int a=3,b=4;
//2	int a=4,b=4;   you can uncomment this line (warning:1,2,3(14,15,16 lines) you can uncomment from the lines ONLY ONE!
//3	int a=5,b=4;
	p_uchar_d charac="Selam";
//	you can uncomment for try MIN macro (warning:You have to uncomment before line 6) 
//	printf("min=%d\na=%d\nb=%d\n",MIN(a++,b),a,b);  
//you can uncomment for try MAX macro (warning:You have to uncomment before line 7) 
//	printf("max=%d\na=%d\nb=%d\n",MAX(a++,b),a,b); 
//	printf(charac);
	
	return 0;
}
