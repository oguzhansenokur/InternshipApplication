#include <stdio.h>
#include <stdlib.h>
#include<string.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int compare(unsigned int y){
	int rslt;
	int x=21033222;
	(int) y;
	if(x==y)
	{
		rslt=0;
	}
	else if(x<y)
	
	{
		rslt=-1;
	}
	else if(x>y)
	{
		rslt=1;
	}
	
	
	return rslt;
	

}

unsigned int find_value(void) {
  unsigned int value = 1;
  unsigned int valuem;
  unsigned int valueh=4294967295;
 int result;
 valuem=(value+valueh)/2;
 if(compare(valuem)==0)
 	{
 		return valuem;
	 }
	
 /*Rewrite this do-while block using binary search */
 do {
 	
 	 if(compare(valuem)==1)
	 {
	 	value=valuem;
	 	valuem=(valueh+valuem)/2;
	 }
	 else{
	 	valueh=valuem;
	 	valuem=(valuem+value)/2;
	 }
 	
/*
 result = compare(value);
value++;
*/
 } while (compare(valuem)!=0);
 
 
 return valuem;
}





int main(int argc, char *argv[]) {
	int x=find_value();
	printf("%d",x);
	return 0;
}
