#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
unsigned int x = 5;
int y = -3;
 //Here is the false code...
 /*if (!(y < x)) {
 printf("func1()");
 }
 else {
 printf("func2()");
 }
*/	
	if(y<0||y<x)//I should check before is y less than 0 then it must be int OR if y is not less than 0 then we can directly compare them
	{
		printf("func1()");
	}

	else//if the conditions of if(y<0||y<x) false it should call func2
	{
		printf("func2()");
	}
	return 0;
}
